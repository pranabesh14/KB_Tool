# ⚡ Angular AI Upgrader

**AI-powered migration tool** — upgrades Angular 1.x / AngularJS projects to **Angular 17+**,  
fixes security vulnerabilities, converts all TypeScript, and generates a full migration report.

---

## Features

| Feature | Detail |
|---------|--------|
| 🔍 **Project Analysis** | Deep inventory of all AngularJS patterns, dependencies, security issues |
| 📋 **Migration Planning** | File-by-file plan with dependency ordering |
| 📦 **Dependency Migration** | Updates package.json, tsconfig, angular.json, .eslintrc |
| ⚙️ **Code Migration** | Converts controllers → components, factories → services, routes, templates |
| 🛡️ **Security Hardening** | Static scan + AI fixes for XSS, injection, hardcoded secrets, etc. |
| ✅ **Validation & Report** | Completeness checklist, build instructions, manual steps |

---

## Requirements

- Python 3.9+
- Node.js 18+ (for building the migrated project)
- Anthropic API key (`claude-opus-4-6` or `claude-sonnet-4-6`)

---

## Installation

```bash
# 1. Clone / copy this directory to your machine
cd angular_upgrader

# 2. Create a virtual environment (recommended)
python -m venv venv
source venv/bin/activate        # macOS / Linux
venv\Scripts\activate.bat       # Windows

# 3. Install dependencies
pip install -r requirements.txt

# 4. Set your Anthropic API key
export ANTHROPIC_API_KEY=sk-ant-...          # macOS / Linux
set ANTHROPIC_API_KEY=sk-ant-...             # Windows CMD
$env:ANTHROPIC_API_KEY="sk-ant-..."          # Windows PowerShell
```

---

## Usage

### Basic Migration

```bash
python main.py --input ./my-angular-app --output ./my-angular-app-v17
```

### With All Options

```bash
python main.py \
  --input  ./my-angular-app \
  --output ./my-angular-app-v17 \
  --verbose \
  --log-file migration.log
```

### Dry Run (Analysis + Plan Only — No Files Written)

```bash
python main.py --input ./my-app --dry-run
```

### Skip Security Phase (Faster)

```bash
python main.py --input ./my-app --skip-security
```

### Resume from a Specific Phase

If a run was interrupted, resume without re-running earlier phases:

```bash
python main.py --input ./my-app --skip-to migrate
```

### All CLI Options

| Option | Description |
|--------|-------------|
| `--input / -i` | Path to Angular 1.x project directory **(required)** |
| `--output / -o` | Output directory (default: `<input>_angular17`) |
| `--api-key` | Anthropic API key (or use `ANTHROPIC_API_KEY` env var) |
| `--model` | Claude model (default: `claude-opus-4-6`) |
| `--dry-run` | Analysis and planning only, no files written |
| `--skip-security` | Skip security hardening phase |
| `--skip-to` | Skip phases before: `analyze|plan|dependencies|migrate|security|validate` |
| `--verbose / -v` | Enable debug output |
| `--log-file` | Write full log to file |

---

## Migration Pipeline

```
Phase 0  📁  Project Scan          Read all files, detect Angular version
Phase 1  🔍  Analysis              AI inventories all patterns, dependencies, security
Phase 2  📋  Planning              AI creates file-by-file migration plan
Phase 3  📦  Dependency Migration  package.json, tsconfig, angular.json → Angular 17
Phase 4  ⚙️  Code Migration        All .ts/.js/.html → Angular 17 (batched)
Phase 5  🛡️  Security Hardening   Static scan + AI fixes for vulnerabilities
Phase 6  ✅  Validation & Report   Completeness check + MIGRATION_REPORT.md
```

---

## What Gets Migrated

### Code Patterns
| AngularJS | Angular 17 |
|-----------|-----------|
| `angular.module()` | `@NgModule` / `bootstrapApplication` |
| `.controller()` + `$scope` | `@Component` + class properties |
| `.factory()` / `.service()` | `@Injectable({ providedIn: 'root' })` |
| `.directive()` | `@Component` / `@Directive` (standalone) |
| `.filter()` | `@Pipe` (standalone) |
| `$http` | `HttpClient` (typed) |
| `$q` / `$q.defer()` | RxJS `Observable` |
| `$routeProvider` / `ui-router` | `@angular/router` |
| `$watch` / `$digest` | RxJS, signals, `ngOnChanges` |
| `ng-*` directives | Angular template syntax |
| `$timeout` / `$interval` | `timer()` / `interval()` (RxJS) |
| `$broadcast` / `$emit` | `Subject` / `EventEmitter` |

### Security Fixes
| Issue | Severity | Fix Applied |
|-------|----------|-------------|
| `eval()` | CRITICAL | Removed / replaced |
| `innerHTML =` | HIGH | DomSanitizer |
| `$sce.trustAsHtml` | HIGH | DomSanitizer |
| Hardcoded secrets | CRITICAL | → environment variables |
| `http://` URLs | MEDIUM | → `https://` |
| `document.write()` | HIGH | DOM API replacement |
| `console.log` in prod | LOW | Removed |

---

## Output Structure

```
my-angular-app-v17/
├── src/
│   ├── app/
│   │   ├── app.config.ts        ← bootstrapApplication config
│   │   ├── app.routes.ts        ← root routes
│   │   ├── core/
│   │   ├── shared/
│   │   └── features/
│   ├── environments/
│   ├── main.ts
│   ├── index.html
│   └── styles.scss
├── package.json                 ← Angular 17 dependencies
├── tsconfig.json                ← strict TypeScript
├── angular.json                 ← updated workspace
├── .eslintrc.json               ← ESLint (replaces TSLint)
├── MIGRATION_REPORT.md          ← Full migration report
├── DIFF_SUMMARY.md              ← What changed
└── .migration_logs/             ← Per-phase AI output logs
    ├── phase_analyze.md
    ├── phase_plan.md
    ├── phase_dependencies.md
    ├── phase_migrate.md
    ├── phase_security.md
    └── phase_validate.md
```

---

## After Migration

```bash
cd my-angular-app-v17

# Install Angular 17 dependencies
npm install

# Start development server
ng serve

# Production build
ng build --configuration production

# Run tests
ng test

# Lint
ng lint
```

---

## Cost Estimate

Using `claude-opus-4-6` (recommended for production quality):

| Project Size | Approx. Input Tokens | Approx. Cost |
|-------------|---------------------|-------------|
| Small (< 50 files) | ~200K | ~$3–5 |
| Medium (50–200 files) | ~500K | ~$8–15 |
| Large (200–500 files) | ~1M | ~$20–40 |
| Very Large (500+ files) | ~2M+ | ~$50–100 |

Use `--model claude-sonnet-4-6` for a 5× cost reduction with slightly lower quality.

---

## Limitations & Manual Steps

The tool automates ~85–90% of a migration. You will still need to:

1. **Review and test** — AI-generated code must be reviewed before production deployment
2. **API endpoints** — Update `environment.ts` with real backend URLs
3. **Authentication** — Auth libraries (Auth0, Okta, etc.) need manual configuration
4. **Third-party libraries** — Some AngularJS-specific libraries have no Angular equivalent
5. **Complex custom directives** — Very complex directives may need manual refinement
6. **E2E tests** — Protractor → Cypress/Playwright migration is not included
7. **CI/CD pipelines** — Update your build pipelines to use Angular CLI 17

---

## Troubleshooting

**`ANTHROPIC_API_KEY` not set**
```bash
export ANTHROPIC_API_KEY=sk-ant-api03-...
```

**`ModuleNotFoundError: No module named 'anthropic'`**
```bash
pip install -r requirements.txt
```

**Rate limit errors** — The tool automatically retries with exponential backoff.
For very large projects, consider using `--skip-to` to run in segments.

**File encoding errors** — Files with non-UTF-8 encoding are read with latin-1 fallback.
Check `.migration_logs/` for any per-file errors.

---

## Architecture

```
angular_upgrader/
├── main.py                      Entry point
├── config/
│   └── settings.py              All configuration (API, file patterns, rules)
├── core/
│   ├── scanner.py               Project file scanner + batching
│   ├── ai_client.py             Anthropic API client (streaming, retry)
│   └── writer.py                Output file writer
├── phases/
│   ├── phase1_analyze.py        Project analysis
│   ├── phase2_plan.py           Migration planning
│   ├── phase3_dependencies.py   Config file migration
│   ├── phase4_migrate.py        Code migration (batched)
│   ├── phase5_security.py       Security hardening
│   └── phase6_validate.py       Validation + report
└── ui/
    ├── cli.py                   CLI orchestrator
    └── logger.py                Terminal output
```
