"""
Configuration for Angular AI Upgrader.
All tuneable parameters live here.
"""

import os
from dataclasses import dataclass, field
from typing import List, Dict


# ─── Anthropic API ────────────────────────────────────────────────────────────
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
ANTHROPIC_MODEL   = "claude-opus-4-6"          # Use Opus for production quality
ANTHROPIC_FALLBACK_MODEL = "claude-sonnet-4-6"  # Fallback if Opus quota exceeded
MAX_TOKENS        = 8192
API_TIMEOUT       = 300  # seconds per request
MAX_RETRIES       = 3
RETRY_DELAY       = 5    # seconds


# ─── File Handling ────────────────────────────────────────────────────────────
# Extensions to process
SOURCE_EXTENSIONS = {
    ".ts", ".js", ".html", ".css", ".scss", ".sass", ".less",
    ".json", ".spec.ts", ".spec.js", ".module.ts", ".module.js",
    ".component.ts", ".component.html", ".component.scss",
    ".service.ts", ".directive.ts", ".pipe.ts", ".guard.ts",
    ".interceptor.ts", ".resolver.ts", ".decorator.ts",
}

# Extensions to copy as-is (binary / generated)
PASSTHROUGH_EXTENSIONS = {
    ".png", ".jpg", ".jpeg", ".gif", ".svg", ".ico",
    ".woff", ".woff2", ".ttf", ".eot",
    ".pdf", ".zip", ".gz",
    ".env", ".env.example",
}

# Always skip these directories
SKIP_DIRS = {
    "node_modules", ".git", "dist", "build", ".angular",
    "coverage", ".nyc_output", "e2e", "__pycache__",
    ".vscode", ".idea", ".cache",
}

# Always skip these files
SKIP_FILES = {
    "package-lock.json", "yarn.lock", "pnpm-lock.yaml",
    ".DS_Store", "Thumbs.db",
}

# Max file size to send to AI (bytes) - files larger than this are chunked
MAX_FILE_SIZE_BYTES = 80_000   # ~80 KB

# Max total tokens to send in one batch
MAX_BATCH_TOKENS = 100_000


# ─── Migration Phases ─────────────────────────────────────────────────────────
PHASES = [
    {
        "id":    "analyze",
        "name":  "Project Analysis",
        "icon":  "🔍",
        "desc":  "Scan project structure, detect Angular version, inventory all patterns",
    },
    {
        "id":    "plan",
        "name":  "Migration Planning",
        "icon":  "📋",
        "desc":  "Build file-by-file migration plan with dependency order",
    },
    {
        "id":    "dependencies",
        "name":  "Dependency Migration",
        "icon":  "📦",
        "desc":  "Update package.json, tsconfig, angular.json to Angular 17+",
    },
    {
        "id":    "migrate",
        "name":  "Code Migration",
        "icon":  "⚙️",
        "desc":  "Convert all AngularJS/Angular 1.x code to Angular 17+ TypeScript",
    },
    {
        "id":    "security",
        "name":  "Security Hardening",
        "icon":  "🛡️",
        "desc":  "Detect and fix XSS, injection, insecure patterns, vulnerable dependencies",
    },
    {
        "id":    "validate",
        "name":  "Validation & Report",
        "icon":  "✅",
        "desc":  "Verify migration completeness and generate final report",
    },
]


# ─── Angular Migration Rules ──────────────────────────────────────────────────
ANGULAR_VERSION_MARKERS = {
    "1.x": [
        "angular.module(",
        "ng-controller",
        "$scope",
        "$routeProvider",
        "$http.get(",
        ".controller(",
        ".factory(",
        ".directive(",
        "angular.bootstrap(",
        "ng-app=",
    ],
    "2-8": [
        "@NgModule(",
        "@Component(",
        "platformBrowserDynamic",
        "RouterModule.forRoot",
    ],
}

NG1_TO_NG17_DIRECTIVES = {
    "ng-model":       "[(ngModel)]",
    "ng-bind":        "{{ }}",
    "ng-bind-html":   "[innerHTML] (with DomSanitizer)",
    "ng-if":          "*ngIf",
    "ng-show":        "*ngIf or [hidden]",
    "ng-hide":        "*ngIf (inverted) or [hidden]",
    "ng-repeat":      "*ngFor",
    "ng-click":       "(click)",
    "ng-submit":      "(ngSubmit)",
    "ng-change":      "(ngModelChange) or (change)",
    "ng-class":       "[ngClass]",
    "ng-style":       "[ngStyle]",
    "ng-src":         "[src]",
    "ng-href":        "[href] or routerLink",
    "ng-disabled":    "[disabled]",
    "ng-checked":     "[checked]",
    "ng-selected":    "[selected]",
    "ng-value":       "[value]",
    "ng-include":     "Component or ng-template",
    "ng-switch":      "ngSwitch / *ngSwitchCase",
    "ng-transclude":  "ng-content",
    "ng-form":        "FormGroup / FormBuilder",
    "ng-required":    "Validators.required",
    "ng-minlength":   "Validators.minLength()",
    "ng-maxlength":   "Validators.maxLength()",
    "ng-pattern":     "Validators.pattern()",
    "ng-options":     "*ngFor in <select>",
    "ng-pluralize":   "NgPlural / i18n pipe",
    "ng-init":        "ngOnInit()",
    "ng-app":         "bootstrapApplication() / main.ts",
    "ng-controller":  "@Component decorator",
    "ng-view":        "<router-outlet>",
    "ng-animate":     "@angular/animations",
}

SECURITY_PATTERNS = [
    {
        "pattern":     r"eval\s*\(",
        "severity":    "CRITICAL",
        "cwe":         "CWE-95",
        "description": "Use of eval() - arbitrary code execution",
        "fix":         "Remove eval(); use JSON.parse() or safe alternatives",
    },
    {
        "pattern":     r"innerHTML\s*=",
        "severity":    "HIGH",
        "cwe":         "CWE-79",
        "description": "Direct innerHTML assignment - XSS risk",
        "fix":         "Use DomSanitizer.bypassSecurityTrustHtml() or textContent",
    },
    {
        "pattern":     r"\$sce\.trustAsHtml\(",
        "severity":    "HIGH",
        "cwe":         "CWE-79",
        "description": "$sce.trustAsHtml bypasses Angular XSS protection",
        "fix":         "Use DomSanitizer with explicit sanitization",
    },
    {
        "pattern":     r"document\.write\(",
        "severity":    "HIGH",
        "cwe":         "CWE-79",
        "description": "document.write() - XSS risk",
        "fix":         "Use DOM APIs or Angular template binding",
    },
    {
        "pattern":     r"new\s+Function\s*\(",
        "severity":    "CRITICAL",
        "cwe":         "CWE-95",
        "description": "Dynamic function construction",
        "fix":         "Replace with explicit function definitions",
    },
    {
        "pattern":     r"localStorage\s*\[|localStorage\.setItem",
        "severity":    "MEDIUM",
        "cwe":         "CWE-922",
        "description": "Sensitive data in localStorage (unencrypted)",
        "fix":         "Encrypt sensitive data or use sessionStorage with care",
    },
    {
        "pattern":     r"http://",
        "severity":    "MEDIUM",
        "cwe":         "CWE-319",
        "description": "Cleartext HTTP URL - should use HTTPS",
        "fix":         "Replace http:// with https://",
    },
    {
        "pattern":     r"console\.(log|debug|info)\s*\(",
        "severity":    "LOW",
        "cwe":         "CWE-532",
        "description": "Console logging in production code",
        "fix":         "Remove console.log or use a logging service",
    },
    {
        "pattern":     r"TODO|FIXME|HACK|XXX",
        "severity":    "LOW",
        "cwe":         "N/A",
        "description": "Unresolved TODO/FIXME comments",
        "fix":         "Resolve before production deployment",
    },
    {
        "pattern":     r"password\s*=\s*['\"]",
        "severity":    "CRITICAL",
        "cwe":         "CWE-259",
        "description": "Hardcoded password",
        "fix":         "Move to environment variables",
    },
    {
        "pattern":     r"apikey\s*[=:]\s*['\"]|api_key\s*[=:]\s*['\"]",
        "severity":    "CRITICAL",
        "cwe":         "CWE-798",
        "description": "Hardcoded API key",
        "fix":         "Move to environment variables",
    },
]

# Target Angular version and dependencies
TARGET_ANGULAR_VERSION = "17"
TARGET_DEPENDENCIES = {
    "@angular/animations":       "^17.0.0",
    "@angular/common":           "^17.0.0",
    "@angular/compiler":         "^17.0.0",
    "@angular/core":             "^17.0.0",
    "@angular/forms":            "^17.0.0",
    "@angular/platform-browser": "^17.0.0",
    "@angular/platform-browser-dynamic": "^17.0.0",
    "@angular/router":           "^17.0.0",
    "rxjs":                      "~7.8.0",
    "tslib":                     "^2.6.0",
    "zone.js":                   "~0.14.0",
}

TARGET_DEV_DEPENDENCIES = {
    "@angular-devkit/build-angular": "^17.0.0",
    "@angular/cli":                  "^17.0.0",
    "@angular/compiler-cli":         "^17.0.0",
    "@types/node":                   "^18.18.0",
    "typescript":                    "~5.2.2",
    "karma":                         "~6.4.0",
    "karma-chrome-launcher":         "~3.2.0",
    "karma-coverage":                "~2.2.0",
    "karma-jasmine":                 "~5.1.0",
    "karma-jasmine-html-reporter":   "~2.1.0",
    "@types/jasmine":                "~5.1.0",
    "jasmine-core":                  "~5.1.0",
}

TARGET_TSCONFIG = {
    "compileOnSave": False,
    "compilerOptions": {
        "baseUrl":                  "./",
        "outDir":                   "./dist/out-tsc",
        "forceConsistentCasingInFileNames": True,
        "strict":                   True,
        "noImplicitOverride":       True,
        "noPropertyAccessFromIndexSignature": True,
        "noImplicitReturns":        True,
        "noFallthroughCasesInSwitch": True,
        "sourceMap":                True,
        "declaration":              False,
        "downlevelIteration":       True,
        "experimentalDecorators":   True,
        "moduleResolution":         "node",
        "importHelpers":            True,
        "target":                   "ES2022",
        "module":                   "ES2022",
        "useDefineForClassFields":  False,
        "lib":                      ["ES2022", "dom"],
    },
    "angularCompilerOptions": {
        "enableI18nLegacyMessageIdFormat": False,
        "strictInjectionParameters":       True,
        "strictInputAccessModifiers":      True,
        "strictTemplates":                 True,
    },
}
