"""
Anthropic API client.
Handles streaming responses, retries, rate-limit back-off, and token budgeting.
"""

import time
import json
import re
import sys
from typing import Optional, Callable, Generator

import anthropic

from config.settings import (
    ANTHROPIC_API_KEY,
    ANTHROPIC_MODEL,
    ANTHROPIC_FALLBACK_MODEL,
    MAX_TOKENS,
    MAX_RETRIES,
    RETRY_DELAY,
    API_TIMEOUT,
)


class APIError(Exception):
    """Raised when the Anthropic API returns a non-retryable error."""


class RateLimitError(Exception):
    """Raised when rate-limited (retryable)."""


class AIClient:
    """
    Wrapper around the Anthropic Python SDK.
    Supports streaming, automatic retries, model fallback, and response parsing.
    """

    def __init__(self, api_key: Optional[str] = None, logger=None):
        key = api_key or ANTHROPIC_API_KEY
        if not key:
            raise ValueError(
                "ANTHROPIC_API_KEY is not set. "
                "Export it: export ANTHROPIC_API_KEY=sk-ant-..."
            )
        self.client = anthropic.Anthropic(api_key=key, timeout=API_TIMEOUT)
        self.logger = logger
        self.model = ANTHROPIC_MODEL
        self.total_input_tokens = 0
        self.total_output_tokens = 0
        self.total_api_calls = 0

    # ─── Public API ────────────────────────────────────────────────────────

    def complete(
        self,
        system: str,
        user: str,
        max_tokens: int = MAX_TOKENS,
        on_chunk: Optional[Callable[[str], None]] = None,
        phase_name: str = "",
    ) -> str:
        """
        Send a prompt to Claude and return the full response text.
        If on_chunk is provided, streams the response and calls on_chunk
        with the accumulated text after each chunk.
        """
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                return self._call(system, user, max_tokens, on_chunk, phase_name)
            except RateLimitError as e:
                wait = RETRY_DELAY * (2 ** (attempt - 1))
                if self.logger:
                    self.logger.warning(f"Rate limited. Waiting {wait}s (attempt {attempt}/{MAX_RETRIES})")
                time.sleep(wait)
            except anthropic.APIStatusError as e:
                if e.status_code in (529, 503):
                    # Overloaded — try fallback model
                    if self.model != ANTHROPIC_FALLBACK_MODEL:
                        if self.logger:
                            self.logger.warning(f"Model overloaded, switching to fallback: {ANTHROPIC_FALLBACK_MODEL}")
                        self.model = ANTHROPIC_FALLBACK_MODEL
                        continue
                    wait = RETRY_DELAY * attempt
                    time.sleep(wait)
                elif e.status_code == 429:
                    wait = RETRY_DELAY * (2 ** attempt)
                    if self.logger:
                        self.logger.warning(f"429 rate limit. Waiting {wait}s")
                    time.sleep(wait)
                else:
                    raise APIError(f"Anthropic API error {e.status_code}: {e.message}") from e
            except Exception as e:
                if attempt == MAX_RETRIES:
                    raise APIError(f"API call failed after {MAX_RETRIES} attempts: {e}") from e
                time.sleep(RETRY_DELAY)

        raise APIError(f"API call failed after {MAX_RETRIES} retries")

    def complete_json(
        self,
        system: str,
        user: str,
        max_tokens: int = MAX_TOKENS,
        phase_name: str = "",
    ) -> dict:
        """Call the API expecting a JSON response. Strips markdown fences."""
        raw = self.complete(system, user, max_tokens, phase_name=phase_name)
        return self._parse_json(raw)

    def stats(self) -> str:
        return (
            f"API calls: {self.total_api_calls} | "
            f"Input tokens: {self.total_input_tokens:,} | "
            f"Output tokens: {self.total_output_tokens:,}"
        )

    # ─── Private ───────────────────────────────────────────────────────────

    def _call(
        self,
        system: str,
        user: str,
        max_tokens: int,
        on_chunk: Optional[Callable[[str], None]],
        phase_name: str,
    ) -> str:
        self.total_api_calls += 1
        full_text = ""

        if on_chunk:
            # Streaming mode
            with self.client.messages.stream(
                model=self.model,
                max_tokens=max_tokens,
                system=system,
                messages=[{"role": "user", "content": user}],
            ) as stream:
                for text in stream.text_stream:
                    full_text += text
                    on_chunk(full_text)
                # Get final message for token counts
                msg = stream.get_final_message()
                self.total_input_tokens  += msg.usage.input_tokens
                self.total_output_tokens += msg.usage.output_tokens
        else:
            # Non-streaming
            msg = self.client.messages.create(
                model=self.model,
                max_tokens=max_tokens,
                system=system,
                messages=[{"role": "user", "content": user}],
            )
            full_text = msg.content[0].text
            self.total_input_tokens  += msg.usage.input_tokens
            self.total_output_tokens += msg.usage.output_tokens

        return full_text

    def _parse_json(self, text: str) -> dict:
        """Strip markdown fences and parse JSON."""
        cleaned = re.sub(r"^```(?:json)?\s*", "", text.strip(), flags=re.MULTILINE)
        cleaned = re.sub(r"\s*```$", "", cleaned.strip(), flags=re.MULTILINE)
        cleaned = cleaned.strip()
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError as e:
            # Try to extract JSON object from mixed content
            match = re.search(r"\{[\s\S]*\}", cleaned)
            if match:
                try:
                    return json.loads(match.group())
                except json.JSONDecodeError:
                    pass
            raise ValueError(f"Could not parse JSON response: {e}\nRaw: {text[:500]}")


def extract_migrated_files(ai_response: str) -> dict:
    """
    Parse AI response and extract migrated file content.

    Expects blocks like:
        === MIGRATED FILE: src/app/app.component.ts ===
        ```typescript
        <code>
        ```
        === END FILE ===

    Returns: { "src/app/app.component.ts": "<code>" }
    """
    files = {}

    # Pattern 1: === MIGRATED FILE: path === ... === END FILE ===
    pattern1 = re.compile(
        r"===\s*MIGRATED FILE:\s*(.+?)\s*===\s*"
        r"```[\w]*\n([\s\S]*?)```\s*"
        r"===\s*END FILE\s*===",
        re.IGNORECASE,
    )
    for match in pattern1.finditer(ai_response):
        path, code = match.group(1).strip(), match.group(2)
        files[path] = code

    # Pattern 2: ### FILE: path\n```lang\ncode```
    if not files:
        pattern2 = re.compile(
            r"###\s*(?:MIGRATED\s+)?FILE:\s*(.+?)\n```[\w]*\n([\s\S]*?)```",
            re.IGNORECASE,
        )
        for match in pattern2.finditer(ai_response):
            path, code = match.group(1).strip(), match.group(2)
            files[path] = code

    # Pattern 3: // FILE: path (for inline code blocks)
    if not files:
        pattern3 = re.compile(
            r"//\s*FILE:\s*(.+?)\n([\s\S]*?)(?=//\s*FILE:|$)",
            re.IGNORECASE,
        )
        for match in pattern3.finditer(ai_response):
            path, code = match.group(1).strip(), match.group(2).strip()
            if code:
                files[path] = code

    return files
