"""
Project file scanner.
Walks the input directory, classifies files, reads content,
and prepares batches for AI processing.
"""

import os
import re
import json
import hashlib
from pathlib import Path
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass, field

from config.settings import (
    SOURCE_EXTENSIONS,
    PASSTHROUGH_EXTENSIONS,
    SKIP_DIRS,
    SKIP_FILES,
    MAX_FILE_SIZE_BYTES,
    ANGULAR_VERSION_MARKERS,
)


@dataclass
class ProjectFile:
    """Represents a single file in the project."""
    rel_path: str               # Relative path from project root
    abs_path: str               # Absolute path on disk
    extension: str              # File extension
    size_bytes: int             # File size
    content: Optional[str]      # Text content (None for binary/passthrough)
    is_source: bool             # Should be sent to AI
    is_passthrough: bool        # Should be copied as-is
    checksum: str               # MD5 of content


@dataclass
class ProjectScan:
    """Result of scanning an Angular project."""
    root_path: str
    files: List[ProjectFile] = field(default_factory=list)
    detected_version: str = "unknown"
    version_markers: List[str] = field(default_factory=list)
    total_files: int = 0
    source_files: int = 0
    passthrough_files: int = 0
    skipped_files: int = 0
    total_size_bytes: int = 0
    file_tree: str = ""
    errors: List[str] = field(default_factory=list)

    def get_source_files(self) -> List[ProjectFile]:
        return [f for f in self.files if f.is_source]

    def get_passthrough_files(self) -> List[ProjectFile]:
        return [f for f in self.files if f.is_passthrough]

    def get_files_by_extension(self, ext: str) -> List[ProjectFile]:
        return [f for f in self.files if f.extension == ext]

    def summary(self) -> str:
        lines = [
            f"Project root  : {self.root_path}",
            f"Angular ver.  : {self.detected_version}",
            f"Total files   : {self.total_files}",
            f"Source files  : {self.source_files}  (will be migrated)",
            f"Passthrough   : {self.passthrough_files}  (copied as-is)",
            f"Skipped       : {self.skipped_files}",
            f"Total size    : {self.total_size_bytes / 1024:.1f} KB",
        ]
        if self.version_markers:
            lines.append(f"Version hints : {', '.join(self.version_markers[:5])}")
        return "\n".join(lines)


class ProjectScanner:
    """Scans an Angular project directory."""

    def __init__(self, logger=None):
        self.logger = logger

    def scan(self, project_path: str) -> ProjectScan:
        root = Path(project_path).resolve()
        if not root.exists():
            raise FileNotFoundError(f"Project path not found: {project_path}")
        if not root.is_dir():
            raise NotADirectoryError(f"Not a directory: {project_path}")

        scan = ProjectScan(root_path=str(root))
        self._walk(root, root, scan)
        scan.total_files = len(scan.files)
        scan.source_files = sum(1 for f in scan.files if f.is_source)
        scan.passthrough_files = sum(1 for f in scan.files if f.is_passthrough)
        scan.total_size_bytes = sum(f.size_bytes for f in scan.files)
        scan.detected_version, scan.version_markers = self._detect_version(scan)
        scan.file_tree = self._build_tree(root)
        return scan

    def _walk(self, root: Path, current: Path, scan: ProjectScan):
        try:
            entries = sorted(current.iterdir(), key=lambda e: (e.is_file(), e.name))
        except PermissionError as e:
            scan.errors.append(f"Permission denied: {current}")
            return

        for entry in entries:
            if entry.is_dir():
                if entry.name in SKIP_DIRS:
                    scan.skipped_files += 1
                    continue
                self._walk(root, entry, scan)
            elif entry.is_file():
                if entry.name in SKIP_FILES:
                    scan.skipped_files += 1
                    continue
                self._process_file(root, entry, scan)

    def _process_file(self, root: Path, entry: Path, scan: ProjectScan):
        rel = str(entry.relative_to(root))
        ext = "".join(entry.suffixes).lower()
        # Handle compound extensions like .component.ts
        if not ext:
            ext = entry.suffix.lower()

        size = entry.stat().st_size

        # Passthrough (binary assets)
        if entry.suffix.lower() in PASSTHROUGH_EXTENSIONS:
            scan.files.append(ProjectFile(
                rel_path=rel, abs_path=str(entry), extension=ext,
                size_bytes=size, content=None,
                is_source=False, is_passthrough=True, checksum="",
            ))
            return

        # Source file — try to read
        is_source = entry.suffix.lower() in SOURCE_EXTENSIONS
        content = None
        checksum = ""

        if is_source or ext in {".json", ".md", ".txt", ".gitignore", ".editorconfig"}:
            try:
                raw = entry.read_bytes()
                # Try UTF-8 first, then latin-1
                try:
                    content = raw.decode("utf-8")
                except UnicodeDecodeError:
                    content = raw.decode("latin-1", errors="replace")
                checksum = hashlib.md5(raw).hexdigest()
            except Exception as e:
                scan.errors.append(f"Could not read {rel}: {e}")
                is_source = False

        if size > MAX_FILE_SIZE_BYTES and is_source:
            # Mark oversized files — they'll be chunked during migration
            pass  # still include them, chunker handles splitting

        scan.files.append(ProjectFile(
            rel_path=rel, abs_path=str(entry), extension=ext,
            size_bytes=size, content=content,
            is_source=is_source, is_passthrough=False, checksum=checksum,
        ))

    def _detect_version(self, scan: ProjectScan) -> Tuple[str, List[str]]:
        """Detect Angular version from package.json and source markers."""
        found_markers = []

        # Check package.json
        for f in scan.files:
            if f.rel_path in ("package.json",) and f.content:
                try:
                    pkg = json.loads(f.content)
                    deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
                    for name, ver in deps.items():
                        if name == "angular" and not name.startswith("@angular/"):
                            # AngularJS
                            found_markers.append(f"angular@{ver}")
                            return "1.x (AngularJS)", found_markers
                        if name == "@angular/core":
                            # Modern Angular
                            ver_clean = ver.lstrip("^~")
                            major = ver_clean.split(".")[0]
                            found_markers.append(f"@angular/core@{ver}")
                            return f"{major}.x", found_markers
                        if name in ("angular-cli", "@angular/cli"):
                            found_markers.append(f"{name}@{ver}")
                except json.JSONDecodeError:
                    pass

        # Fallback: scan source for markers
        for f in scan.get_source_files():
            if f.content:
                for marker in ANGULAR_VERSION_MARKERS.get("1.x", []):
                    if marker in f.content:
                        found_markers.append(marker)
                if len(found_markers) >= 3:
                    return "1.x (AngularJS)", found_markers[:5]

        return "unknown", found_markers

    def _build_tree(self, root: Path, max_depth: int = 5) -> str:
        """Build a visual directory tree string."""
        lines = [root.name + "/"]
        self._tree_recurse(root, "", lines, 0, max_depth)
        return "\n".join(lines)

    def _tree_recurse(self, path: Path, prefix: str, lines: List[str], depth: int, max_depth: int):
        if depth >= max_depth:
            return
        try:
            entries = sorted(path.iterdir(), key=lambda e: (e.is_file(), e.name))
        except PermissionError:
            return

        entries = [e for e in entries if e.name not in SKIP_DIRS and e.name not in SKIP_FILES]
        for i, entry in enumerate(entries):
            connector = "└── " if i == len(entries) - 1 else "├── "
            lines.append(f"{prefix}{connector}{entry.name}{'/' if entry.is_dir() else ''}")
            if entry.is_dir():
                extension = "    " if i == len(entries) - 1 else "│   "
                self._tree_recurse(entry, prefix + extension, lines, depth + 1, max_depth)


def batch_files_for_ai(
    files: List[ProjectFile],
    max_chars_per_batch: int = 80_000,
    priority_extensions: Optional[List[str]] = None,
) -> List[List[ProjectFile]]:
    """
    Group files into batches that fit within the AI context window.
    Priority extensions are placed in earlier batches.
    """
    if priority_extensions is None:
        priority_extensions = [".ts", ".js", ".module.ts", ".component.ts", ".service.ts"]

    def sort_key(f: ProjectFile) -> Tuple[int, str]:
        # Config files first, then by extension priority
        if f.rel_path in ("package.json", "tsconfig.json", "angular.json"):
            return (0, f.rel_path)
        for i, ext in enumerate(priority_extensions):
            if f.extension.endswith(ext):
                return (1 + i, f.rel_path)
        return (99, f.rel_path)

    sorted_files = sorted(files, key=sort_key)

    batches: List[List[ProjectFile]] = []
    current_batch: List[ProjectFile] = []
    current_size = 0

    for f in sorted_files:
        content_size = len(f.content) if f.content else 0
        if content_size > max_chars_per_batch:
            # Oversized file gets its own batch
            if current_batch:
                batches.append(current_batch)
                current_batch = []
                current_size = 0
            batches.append([f])
            continue

        if current_size + content_size > max_chars_per_batch and current_batch:
            batches.append(current_batch)
            current_batch = []
            current_size = 0

        current_batch.append(f)
        current_size += content_size

    if current_batch:
        batches.append(current_batch)

    return batches


def format_files_for_prompt(files: List[ProjectFile]) -> str:
    """Format a list of files into a prompt-friendly string."""
    parts = []
    for f in files:
        if f.content is None:
            continue
        lang = _ext_to_lang(f.extension)
        parts.append(f"### FILE: {f.rel_path}\n```{lang}\n{f.content}\n```")
    return "\n\n".join(parts)


def _ext_to_lang(ext: str) -> str:
    mapping = {
        ".ts":   "typescript",
        ".js":   "javascript",
        ".html": "html",
        ".css":  "css",
        ".scss": "scss",
        ".sass": "sass",
        ".less": "less",
        ".json": "json",
        ".md":   "markdown",
    }
    for suffix, lang in mapping.items():
        if ext.endswith(suffix):
            return lang
    return ""
