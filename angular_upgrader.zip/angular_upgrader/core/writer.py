"""
Output writer.
Writes migrated files to the output directory, preserving directory structure.
Handles file conflicts, backups, and provides a diff summary.
"""

import os
import shutil
import difflib
from pathlib import Path
from typing import Dict, List, Optional
from dataclasses import dataclass, field

from core.scanner import ProjectFile, ProjectScan


@dataclass
class WriteResult:
    """Result of writing migrated output."""
    output_path: str
    files_written: int = 0
    files_copied: int = 0
    files_skipped: int = 0
    errors: List[str] = field(default_factory=list)
    written_paths: List[str] = field(default_factory=list)

    def summary(self) -> str:
        return (
            f"Output path    : {self.output_path}\n"
            f"Files written  : {self.files_written}  (migrated)\n"
            f"Files copied   : {self.files_copied}  (assets/passthrough)\n"
            f"Files skipped  : {self.files_skipped}\n"
            f"Errors         : {len(self.errors)}"
        )


class OutputWriter:
    """Writes migrated project to the output directory."""

    def __init__(self, output_path: str, logger=None):
        self.output_path = Path(output_path).resolve()
        self.logger = logger

    def prepare_output_dir(self):
        """Create output directory, backing up if it exists."""
        if self.output_path.exists():
            backup = Path(str(self.output_path) + "_backup")
            if backup.exists():
                shutil.rmtree(backup)
            shutil.copytree(self.output_path, backup)
            shutil.rmtree(self.output_path)
            if self.logger:
                self.logger.info(f"Existing output backed up to: {backup}")
        self.output_path.mkdir(parents=True, exist_ok=True)

    def write_migrated_files(
        self,
        migrated: Dict[str, str],
        original_scan: ProjectScan,
    ) -> WriteResult:
        """
        Write AI-migrated files to output directory.
        Also copies passthrough (binary) files from the original project.
        """
        result = WriteResult(output_path=str(self.output_path))

        # Write migrated source files
        for rel_path, content in migrated.items():
            try:
                self._write_file(rel_path, content)
                result.files_written += 1
                result.written_paths.append(rel_path)
            except Exception as e:
                msg = f"Failed to write {rel_path}: {e}"
                result.errors.append(msg)
                if self.logger:
                    self.logger.error(msg)

        # Copy passthrough files (images, fonts, etc.) from original project
        for f in original_scan.get_passthrough_files():
            try:
                dest = self.output_path / f.rel_path
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(f.abs_path, dest)
                result.files_copied += 1
            except Exception as e:
                msg = f"Failed to copy {f.rel_path}: {e}"
                result.errors.append(msg)

        return result

    def write_file(self, rel_path: str, content: str):
        """Write a single file to the output directory."""
        self._write_file(rel_path, content)

    def write_report(self, report_content: str, filename: str = "MIGRATION_REPORT.md"):
        """Write the migration report to the output directory."""
        report_path = self.output_path / filename
        report_path.write_text(report_content, encoding="utf-8")
        return str(report_path)

    def write_phase_log(self, phase_id: str, content: str):
        """Write a phase log file to a logs subdirectory."""
        logs_dir = self.output_path / ".migration_logs"
        logs_dir.mkdir(exist_ok=True)
        log_file = logs_dir / f"{phase_id}.md"
        log_file.write_text(content, encoding="utf-8")

    def _write_file(self, rel_path: str, content: str):
        dest = self.output_path / rel_path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(content, encoding="utf-8")
        if self.logger:
            self.logger.debug(f"  Written: {rel_path}")

    def generate_diff_summary(
        self,
        original_scan: ProjectScan,
        migrated: Dict[str, str],
    ) -> str:
        """Generate a human-readable diff summary of changes."""
        lines = ["# Migration Diff Summary\n"]
        original_map = {f.rel_path: f.content for f in original_scan.get_source_files()}

        added   = [p for p in migrated if p not in original_map]
        removed = [p for p in original_map if p not in migrated]
        changed = []

        for path in migrated:
            if path in original_map and migrated[path] != original_map[path]:
                changed.append(path)

        lines.append(f"## Summary\n- Added: {len(added)} files\n- Removed: {len(removed)} files\n- Changed: {len(changed)} files\n")

        if added:
            lines.append("## New Files\n" + "\n".join(f"- `{p}`" for p in sorted(added)))
        if removed:
            lines.append("\n## Removed Files\n" + "\n".join(f"- `{p}`" for p in sorted(removed)))
        if changed:
            lines.append("\n## Changed Files")
            for path in sorted(changed)[:50]:  # Limit to first 50
                orig_lines = (original_map[path] or "").splitlines(keepends=True)
                new_lines  = migrated[path].splitlines(keepends=True)
                diff = list(difflib.unified_diff(
                    orig_lines, new_lines,
                    fromfile=f"original/{path}",
                    tofile=f"migrated/{path}",
                    n=0,
                ))
                lines.append(f"\n### `{path}`")
                lines.append(f"Lines changed: {sum(1 for d in diff if d.startswith(('+', '-')) and not d.startswith(('---', '+++', '@@')))}")
                if len(diff) < 60:
                    lines.append("```diff\n" + "".join(diff[:50]) + "\n```")

        return "\n".join(lines)
