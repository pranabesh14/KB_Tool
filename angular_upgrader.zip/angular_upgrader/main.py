#!/usr/bin/env python3
"""
Angular AI Upgrader - Production Grade CLI Tool
Upgrades Angular 1.x / AngularJS projects to Angular 17+
Fixes security vulnerabilities, migrates TypeScript, updates all modules.
"""

import sys
import os

# Ensure project root is on path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ui.cli import CLI


def main():
    cli = CLI()
    cli.run()


if __name__ == "__main__":
    main()
