"""
Phase 1: Project Analysis
Sends project structure + key files to AI for deep inventory.
"""

from core.scanner import ProjectScan, format_files_for_prompt
from core.ai_client import AIClient

SYSTEM_PROMPT = """You are a senior Angular migration engineer with 15+ years of experience.
You perform meticulous technical audits of Angular/AngularJS projects.
Your analysis is exhaustive, precise, and actionable.
Always use markdown formatting with clear headers and tables."""


def build_user_prompt(scan: ProjectScan, file_sample: str) -> str:
    return f"""Perform a comprehensive technical analysis of this Angular project.

## Project Structure
```
{scan.file_tree}
```

## Detected Version
{scan.detected_version}

## Key Project Files
{file_sample}

## Statistics
{scan.summary()}

---

Provide a complete analysis with the following sections:

## 1. Project Overview
- Angular version detected and confirmation method
- Project type (SPA, library, micro-frontend, etc.)
- Module architecture (monolithic NgModule, lazy-loaded, standalone, etc.)
- Total components, services, directives, pipes, guards, interceptors (count each)
- Routing structure summary
- State management approach (if any: NgRx, Akita, NGXS, services, etc.)
- HTTP client usage patterns
- Forms approach (template-driven, reactive, or mixed)
- Testing framework and coverage estimate

## 2. Complete Pattern Inventory
Create a table of EVERY AngularJS/legacy Angular pattern found:
| Pattern | Count | Files Affected | Migration Action |
|---------|-------|----------------|-----------------|

Include: $scope, $http, $q, $routeProvider, .controller(), .factory(), .service(), .directive(), 
$watch, $digest, ng-* directives, $broadcast/$emit/$on, angular.module(), $filter, $compile, 
$timeout, $interval, $location, $anchorScroll, $window, $document, $rootScope, etc.

## 3. Dependency Audit
| Package | Current Version | Status | Angular 17 Equivalent |
|---------|----------------|--------|----------------------|
List ALL dependencies from package.json. Mark as: ✅ Compatible | ⚠️ Needs Update | ❌ Deprecated/Replace | 🔄 Migrate to Angular built-in

## 4. Security Pre-Assessment
| Issue | Severity | File | CWE | Description |
|-------|----------|------|-----|-------------|
Find: eval(), innerHTML, $sce.trustAsHtml, document.write, hardcoded secrets, http:// URLs,
localStorage misuse, new Function(), dangerouslySetInnerHTML, setTimeout with string, etc.

## 5. Breaking Changes to Address
List every Angular 17 breaking change that affects this project, ordered by severity.

## 6. Migration Complexity Assessment
- Overall complexity: Low / Medium / High / Very High
- Estimated hours of work (by phase)
- Top 5 highest-risk migration items
- Recommended migration order for files/modules

## 7. Architecture Recommendations for Angular 17
Specific recommendations for this project:
- Should it use standalone components?
- Should it adopt signals?
- Recommended folder structure
- Recommended lazy-loading strategy
"""


def run(scan: ProjectScan, client: AIClient, on_chunk=None, logger=None) -> str:
    """Run the analysis phase."""
    if logger:
        logger.info("Building analysis prompt...")

    # Prioritise config files + a sample of source files
    priority_files = []
    source_files = scan.get_source_files()

    # Always include config files
    config_names = {"package.json", "tsconfig.json", "angular.json", "tsconfig.app.json",
                    ".angular-cli.json", "angular-cli.json"}
    for f in source_files:
        if f.rel_path in config_names or f.rel_path.split("/")[-1] in config_names:
            priority_files.append(f)

    # Include module files
    for f in source_files:
        if "module" in f.rel_path.lower() and f not in priority_files:
            priority_files.append(f)

    # Include routing files
    for f in source_files:
        if "routing" in f.rel_path.lower() or "routes" in f.rel_path.lower():
            if f not in priority_files:
                priority_files.append(f)

    # Fill up to ~40 files with a representative sample
    remaining = [f for f in source_files if f not in priority_files]
    priority_files.extend(remaining[:40 - len(priority_files)])

    file_sample = format_files_for_prompt(priority_files[:40])

    user_prompt = build_user_prompt(scan, file_sample)

    if logger:
        logger.info(f"Sending {len(priority_files)} representative files to AI for analysis...")

    result = client.complete(
        system=SYSTEM_PROMPT,
        user=user_prompt,
        max_tokens=8192,
        on_chunk=on_chunk,
        phase_name="Analysis",
    )
    return result
