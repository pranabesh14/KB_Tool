"""
Phase 2: Migration Planning
Generates a detailed, file-by-file migration plan with dependency ordering.
"""

from core.scanner import ProjectScan, format_files_for_prompt
from core.ai_client import AIClient

SYSTEM_PROMPT = """You are a senior Angular migration architect.
You create precise, actionable migration plans for large production codebases.
Your plans are dependency-ordered, risk-aware, and production-grade.
Use markdown formatting with tables and clear sections."""


def build_user_prompt(scan: ProjectScan, analysis: str, file_list_str: str) -> str:
    return f"""Create a complete, file-by-file migration plan for this Angular project.

## Previous Analysis
{analysis}

## All Project Files (to migrate)
{file_list_str}

## Project Stats
{scan.summary()}

---

Produce a comprehensive migration plan:

## 1. Target Architecture
Describe the exact Angular 17 architecture for this specific project:
- Standalone components strategy
- Module structure (NgModule vs standalone)
- Routing approach
- State management recommendation
- HTTP client patterns (using HttpClient with typed responses)
- Forms strategy (Reactive Forms recommended)

## 2. New Project Structure
Show the complete target directory structure:
```
src/
├── app/
│   ├── core/
│   │   ├── interceptors/
│   │   ├── guards/
│   │   └── services/
│   ├── shared/
│   │   ├── components/
│   │   ├── directives/
│   │   └── pipes/
│   ├── features/
│   │   └── [feature-modules]/
│   └── ...
```

## 3. Configuration Files to Create/Update
List every config file with exact content targets:
| File | Action | Key Changes |
|------|--------|------------|

## 4. File-by-File Migration Plan
For EVERY source file, provide:
| Original File | Target File | Migration Type | Key Changes | Dependencies |
|--------------|-------------|----------------|-------------|--------------|

Migration Types: CONVERT (AngularJS → Angular 17) | REFACTOR (Angular 2-16 → 17) | SPLIT (one file → many) | MERGE | DELETE | CREATE_NEW

## 5. New Files to Create
List files that must be created from scratch:
| File | Purpose | Template Type |
|------|---------|---------------|
(app.config.ts, main.ts, environment files, etc.)

## 6. Dependency Migration Map
| Old Import | New Import | Notes |
|-----------|-----------|-------|
Map every old module/import to its Angular 17 equivalent.

## 7. Migration Execution Order
List files in DEPENDENCY ORDER — files that others depend on go first:
1. package.json, tsconfig.json, angular.json
2. Core services (no dependencies)
3. Shared components/directives/pipes
4. Feature modules (ordered by dependency)
5. App module / app.config.ts
6. Routing
7. Entry point (main.ts, index.html)

## 8. Risk Register
| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|-----------|

## 9. Validation Checklist
Checklist items to verify after migration completes.
"""


def build_file_list(scan: ProjectScan) -> str:
    """Build a compact file list for the planning prompt."""
    lines = []
    for f in scan.get_source_files():
        size_kb = f.size_bytes / 1024
        lines.append(f"- {f.rel_path} ({size_kb:.1f} KB)")
    return "\n".join(lines)


def run(scan: ProjectScan, analysis: str, client: AIClient, on_chunk=None, logger=None) -> str:
    """Run the planning phase."""
    if logger:
        logger.info("Building migration plan prompt...")

    file_list_str = build_file_list(scan)
    user_prompt = build_user_prompt(scan, analysis, file_list_str)

    if logger:
        logger.info(f"Planning migration for {scan.source_files} source files...")

    result = client.complete(
        system=SYSTEM_PROMPT,
        user=user_prompt,
        max_tokens=8192,
        on_chunk=on_chunk,
        phase_name="Planning",
    )
    return result
