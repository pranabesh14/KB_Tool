"""
Phase 3: Dependency Migration
Updates package.json, tsconfig.json, angular.json, and other config files
to be compatible with Angular 17+.
"""

import json
from typing import Dict

from core.scanner import ProjectScan
from core.ai_client import AIClient, extract_migrated_files
from config.settings import TARGET_ANGULAR_VERSION, TARGET_DEPENDENCIES, TARGET_DEV_DEPENDENCIES, TARGET_TSCONFIG

SYSTEM_PROMPT = """You are an Angular CLI and build tooling expert.
You migrate Angular project configuration files to Angular 17+ with precision.
Always output complete file contents in the specified format.
When outputting migrated files, use EXACTLY this format:

=== MIGRATED FILE: <filepath> ===
```<language>
<complete file content>
```
=== END FILE ===
"""


def get_config_files(scan: ProjectScan) -> Dict[str, str]:
    """Extract all configuration files from the scan."""
    config_names = {
        "package.json", "tsconfig.json", "tsconfig.app.json",
        "tsconfig.spec.json", "tsconfig.base.json",
        "angular.json", ".angular-cli.json", "angular-cli.json",
        "karma.conf.js", ".browserslistrc", ".eslintrc.json",
        ".eslintrc.js", "tslint.json", "jest.config.js",
        "jest.config.ts", "webpack.config.js",
    }
    configs = {}
    for f in scan.get_source_files():
        basename = f.rel_path.split("/")[-1]
        if basename in config_names and f.content:
            configs[f.rel_path] = f.content
    return configs


def build_user_prompt(config_files: Dict[str, str], analysis: str, plan: str) -> str:
    files_section = "\n\n".join(
        f"### FILE: {path}\n```json\n{content}\n```"
        for path, content in config_files.items()
    )

    deps_json = json.dumps(TARGET_DEPENDENCIES, indent=2)
    dev_deps_json = json.dumps(TARGET_DEV_DEPENDENCIES, indent=2)
    tsconfig_json = json.dumps(TARGET_TSCONFIG, indent=2)

    return f"""Migrate all project configuration files to Angular 17+.

## Original Config Files
{files_section}

## Analysis Summary
{analysis[:3000]}

## Migration Plan Notes
{plan[:2000]}

## Target Angular Version
{TARGET_ANGULAR_VERSION}

## Required Angular 17 Dependencies (use these exact versions)
```json
{deps_json}
```

## Required Angular 17 Dev Dependencies
```json
{dev_deps_json}
```

## Target tsconfig.json base
```json
{tsconfig_json}
```

---

Produce the following migrated configuration files:

1. **package.json** — Complete updated file with:
   - All @angular/* packages at ^17.0.0
   - TypeScript ~5.2.2
   - RxJS ~7.8.0
   - Zone.js ~0.14.0
   - Remove all deprecated AngularJS packages (angular, angular-route, angular-mocks, ui-bootstrap, etc.)
   - Keep any non-Angular dependencies (lodash, moment, etc.) at latest stable
   - Add build scripts: start, build, build:prod, test, lint
   - Add engines field: node >=18.0.0

2. **tsconfig.json** — Strict TypeScript config for Angular 17

3. **tsconfig.app.json** — App-specific tsconfig

4. **tsconfig.spec.json** — Test-specific tsconfig

5. **angular.json** — Updated workspace config:
   - Update architect/build builder to @angular-devkit/build-angular:application
   - Update styles/scripts arrays
   - Add production optimization config
   - Add development configuration
   - Configure budget limits

6. **.browserslistrc** — Modern browser targets

7. **.eslintrc.json** — Replace tslint.json with ESLint + Angular ESLint rules

8. **src/environments/environment.ts** — Development environment

9. **src/environments/environment.prod.ts** — Production environment

Output each file in the === MIGRATED FILE: === format.
Be complete — do not truncate any file.
"""


def run(
    scan: ProjectScan,
    analysis: str,
    plan: str,
    client: AIClient,
    on_chunk=None,
    logger=None,
) -> Dict[str, str]:
    """Run the dependency migration phase. Returns dict of {path: content}."""
    if logger:
        logger.info("Extracting configuration files...")

    config_files = get_config_files(scan)
    if logger:
        logger.info(f"Found {len(config_files)} configuration files to migrate")

    user_prompt = build_user_prompt(config_files, analysis, plan)

    result = client.complete(
        system=SYSTEM_PROMPT,
        user=user_prompt,
        max_tokens=8192,
        on_chunk=on_chunk,
        phase_name="Dependencies",
    )

    migrated = extract_migrated_files(result)
    if logger:
        logger.info(f"Generated {len(migrated)} migrated configuration files")

    return migrated, result
