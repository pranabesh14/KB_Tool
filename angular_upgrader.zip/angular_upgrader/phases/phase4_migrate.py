"""
Phase 4: Code Migration
The core phase — converts all AngularJS/Angular 1.x source files to Angular 17+.
Processes files in intelligent batches to handle large projects.
"""

import re
from typing import Dict, List, Tuple

from core.scanner import ProjectScan, ProjectFile, batch_files_for_ai, format_files_for_prompt
from core.ai_client import AIClient, extract_migrated_files
from config.settings import NG1_TO_NG17_DIRECTIVES, MAX_FILE_SIZE_BYTES

SYSTEM_PROMPT = """You are a world-class Angular migration engineer.
You migrate production Angular/AngularJS codebases to Angular 17+ with zero tolerance for errors.

CRITICAL RULES:
- Produce complete, compilable TypeScript — never truncate code
- Preserve ALL business logic exactly — only change framework APIs
- Use Angular 17 standalone components unless NgModule is explicitly needed
- Add proper TypeScript strict types throughout (no 'any' unless unavoidable)
- Use RxJS properly — no deprecated operators, use pipeable operators
- Use inject() function for DI where appropriate (Angular 14+ style)
- Use modern Angular signals where they simplify code (optional but preferred)
- Convert all $http calls to typed HttpClient with proper error handling
- Convert all $q / deferred promises to RxJS Observables
- Use the Angular Router correctly (RouterModule, routerLink, ActivatedRoute, etc.)
- Preserve existing file/folder structure unless restructuring is explicitly required
- Keep all existing comments and add migration notes where needed

OUTPUT FORMAT — use EXACTLY this for every file:
=== MIGRATED FILE: <relative/path/to/file.ts> ===
```typescript
<complete file content>
```
=== END FILE ===
"""


def build_batch_prompt(
    batch: List[ProjectFile],
    analysis: str,
    plan: str,
    batch_num: int,
    total_batches: int,
    previously_migrated_summary: str = "",
) -> str:
    directive_table = "\n".join(
        f"| {k} | {v} |"
        for k, v in list(NG1_TO_NG17_DIRECTIVES.items())[:20]
    )

    files_content = format_files_for_prompt(batch)
    file_list = "\n".join(f"- {f.rel_path}" for f in batch)

    return f"""Migrate the following Angular source files to Angular 17+. Batch {batch_num} of {total_batches}.

## Files in This Batch
{file_list}

## Key Migration Reference
| AngularJS | Angular 17 |
|-----------|-----------|
{directive_table}

## Architecture Notes from Analysis
{analysis[:2000]}

## Migration Plan Notes  
{plan[:2000]}

{f"## Previously Migrated (for import reference){chr(10)}{previously_migrated_summary}" if previously_migrated_summary else ""}

## Files to Migrate
{files_content}

---

Migrate EVERY file listed above. For each file:

1. **Components** (.controller.js / component): 
   - Create @Component decorator with standalone: true
   - Convert $scope properties to class properties
   - Move lifecycle hooks ($onInit → ngOnInit, etc.)
   - Convert ng-* template directives to Angular syntax
   - Add proper imports array

2. **Services** (.factory.js / .service.js):
   - Use @Injectable({{ providedIn: 'root' }}) 
   - Convert $http → HttpClient with typed generics
   - Convert $q.defer() → Observable / Subject patterns
   - Convert $timeout/$interval → timer/interval from rxjs

3. **Directives** (.directive.js):
   - Convert to @Directive with standalone: true
   - Map link/compile functions to lifecycle hooks
   - Convert scope bindings to @Input()/@Output()

4. **Pipes** (.filter.js):
   - Convert to @Pipe with standalone: true
   - Implement PipeTransform interface

5. **Routing**:
   - Convert $routeProvider / ui-router to @angular/router
   - Create Routes array
   - Use lazy loading with loadComponent for feature routes

6. **Templates** (.html):
   - Replace all ng-* with Angular equivalents
   - Replace {{ }} expressions (keep these as-is — they work)
   - Replace ng-bind with property binding or interpolation
   - Replace ng-model with [(ngModel)] or Reactive Forms
   - Add proper Angular imports in the component

Output ALL files. Do not skip any. Do not truncate any file content.
"""


def build_entrypoint_prompt(scan: ProjectScan, all_migrated: Dict[str, str], plan: str) -> str:
    """Prompt to generate Angular 17 entry-point files."""
    migrated_list = "\n".join(f"- {p}" for p in sorted(all_migrated.keys())[:80])

    return f"""Generate the Angular 17 entry-point and bootstrap files for this project.

## Migrated Files Available
{migrated_list}

## Migration Plan
{plan[:3000]}

Generate these files:

1. **src/main.ts** — bootstrapApplication() with app.config.ts
2. **src/app/app.config.ts** — ApplicationConfig with providers
3. **src/app/app.routes.ts** — Root Routes array (lazy-loading feature modules)
4. **src/index.html** — Clean HTML entry point
5. **src/styles.scss** — Global styles (empty but properly structured)

For app.config.ts, include:
- provideRouter(appRoutes, withPreloading(PreloadAllModules))
- provideHttpClient(withInterceptorsFromDi())
- provideAnimations()
- Any other providers from original app.module

Output each in === MIGRATED FILE: === format.
"""


def run(
    scan: ProjectScan,
    analysis: str,
    plan: str,
    dep_migrated: Dict[str, str],
    client: AIClient,
    on_chunk=None,
    logger=None,
) -> Tuple[Dict[str, str], str]:
    """
    Run the code migration phase.
    Returns (all_migrated_files, full_log_text).
    """
    all_migrated: Dict[str, str] = dict(dep_migrated)  # Start with config files
    log_parts = []

    # Get source files excluding config (already handled in phase 3)
    config_names = {
        "package.json", "tsconfig.json", "tsconfig.app.json", "tsconfig.spec.json",
        "tsconfig.base.json", "angular.json", ".angular-cli.json", "angular-cli.json",
        "karma.conf.js", ".eslintrc.json", "tslint.json",
    }
    source_files = [
        f for f in scan.get_source_files()
        if f.rel_path.split("/")[-1] not in config_names
        and f.content is not None
    ]

    if logger:
        logger.info(f"Migrating {len(source_files)} source files...")

    # Batch files for AI processing
    batches = batch_files_for_ai(source_files, max_chars_per_batch=70_000)
    total_batches = len(batches)

    if logger:
        logger.info(f"Split into {total_batches} batches for processing")

    for i, batch in enumerate(batches, 1):
        batch_file_names = [f.rel_path for f in batch]
        if logger:
            logger.info(f"Processing batch {i}/{total_batches} ({len(batch)} files)...")
            for name in batch_file_names[:5]:
                logger.debug(f"  - {name}")
            if len(batch_file_names) > 5:
                logger.debug(f"  ... and {len(batch_file_names) - 5} more")

        # Build context from previously migrated files (brief summary)
        prev_summary = _build_prev_summary(all_migrated, limit=30)

        user_prompt = build_batch_prompt(
            batch=batch,
            analysis=analysis,
            plan=plan,
            batch_num=i,
            total_batches=total_batches,
            previously_migrated_summary=prev_summary,
        )

        chunk_accumulator = [""]
        def _on_chunk(text):
            chunk_accumulator[0] = text
            if on_chunk:
                on_chunk(f"[Batch {i}/{total_batches}]\n{text}")

        result = client.complete(
            system=SYSTEM_PROMPT,
            user=user_prompt,
            max_tokens=8192,
            on_chunk=_on_chunk,
            phase_name=f"Migration batch {i}/{total_batches}",
        )

        batch_migrated = extract_migrated_files(result)
        all_migrated.update(batch_migrated)
        log_parts.append(f"## Batch {i}/{total_batches}\n\n{result}")

        if logger:
            logger.info(f"Batch {i} complete: {len(batch_migrated)} files migrated")

    # Generate entry-point files
    if logger:
        logger.info("Generating Angular 17 entry-point files (main.ts, app.config.ts, etc.)...")

    entry_prompt = build_entrypoint_prompt(scan, all_migrated, plan)

    entry_result = client.complete(
        system=SYSTEM_PROMPT,
        user=entry_prompt,
        max_tokens=4096,
        on_chunk=on_chunk,
        phase_name="Entry-point generation",
    )

    entry_files = extract_migrated_files(entry_result)
    all_migrated.update(entry_files)
    log_parts.append(f"## Entry-point Files\n\n{entry_result}")

    if logger:
        logger.info(f"Entry-point generation complete: {len(entry_files)} files")

    total_migrated = len(all_migrated)
    if logger:
        logger.info(f"Code migration complete. Total files: {total_migrated}")

    return all_migrated, "\n\n---\n\n".join(log_parts)


def _build_prev_summary(migrated: Dict[str, str], limit: int = 30) -> str:
    """Build a brief summary of already-migrated files for context."""
    lines = []
    for path in list(migrated.keys())[:limit]:
        ext = path.split(".")[-1]
        lines.append(f"- {path} ({ext})")
    if len(migrated) > limit:
        lines.append(f"... and {len(migrated) - limit} more files")
    return "\n".join(lines)
