"""
Phase 5: Security Hardening
Static pattern scanning + AI-powered security fixes.
"""

import re
from typing import Dict, List, Tuple
from dataclasses import dataclass, field

from core.scanner import ProjectScan, ProjectFile
from core.ai_client import AIClient, extract_migrated_files
from config.settings import SECURITY_PATTERNS

SYSTEM_PROMPT = """You are a security engineer specialising in Angular application security.
You identify and fix security vulnerabilities in Angular TypeScript codebases.
You are familiar with OWASP Top 10, Angular security best practices, and CWE classifications.

OUTPUT FORMAT for fixed files:
=== MIGRATED FILE: <filepath> ===
```typescript
<complete fixed file content>
```
=== END FILE ===
"""


@dataclass
class SecurityIssue:
    """A detected security vulnerability."""
    file_path: str
    line_number: int
    line_content: str
    severity: str     # CRITICAL, HIGH, MEDIUM, LOW
    cwe: str
    description: str
    fix: str
    pattern: str


@dataclass
class SecurityReport:
    """Complete security audit report."""
    issues: List[SecurityIssue] = field(default_factory=list)
    critical_count: int = 0
    high_count: int = 0
    medium_count: int = 0
    low_count: int = 0

    def add(self, issue: SecurityIssue):
        self.issues.append(issue)
        if issue.severity == "CRITICAL": self.critical_count += 1
        elif issue.severity == "HIGH":   self.high_count += 1
        elif issue.severity == "MEDIUM": self.medium_count += 1
        elif issue.severity == "LOW":    self.low_count += 1

    def summary(self) -> str:
        return (
            f"Critical: {self.critical_count} | "
            f"High: {self.high_count} | "
            f"Medium: {self.medium_count} | "
            f"Low: {self.low_count} | "
            f"Total: {len(self.issues)}"
        )

    def to_markdown(self) -> str:
        if not self.issues:
            return "✅ No security issues detected by static analysis."

        lines = [
            "## Static Analysis Results\n",
            f"**{self.summary()}**\n",
            "| Severity | File | Line | CWE | Description |",
            "|----------|------|------|-----|-------------|",
        ]
        for issue in sorted(self.issues, key=lambda i: ["CRITICAL","HIGH","MEDIUM","LOW"].index(i.severity)):
            short_file = "/".join(issue.file_path.split("/")[-2:])
            lines.append(
                f"| {issue.severity} | `{short_file}` | {issue.line_number} | "
                f"{issue.cwe} | {issue.description} |"
            )
        return "\n".join(lines)


def static_scan(files: Dict[str, str]) -> SecurityReport:
    """
    Run static pattern matching against migrated files.
    Returns a SecurityReport with all detected issues.
    """
    report = SecurityReport()
    compiled = [
        (re.compile(p["pattern"], re.IGNORECASE), p)
        for p in SECURITY_PATTERNS
    ]

    for file_path, content in files.items():
        if not content:
            continue
        lines = content.splitlines()
        for line_no, line in enumerate(lines, 1):
            for regex, pattern_def in compiled:
                if regex.search(line):
                    report.add(SecurityIssue(
                        file_path=file_path,
                        line_number=line_no,
                        line_content=line.strip()[:120],
                        severity=pattern_def["severity"],
                        cwe=pattern_def["cwe"],
                        description=pattern_def["description"],
                        fix=pattern_def["fix"],
                        pattern=pattern_def["pattern"],
                    ))
    return report


def build_security_prompt(
    files_with_issues: Dict[str, str],
    static_report: SecurityReport,
    analysis: str,
) -> str:
    files_section = "\n\n".join(
        f"### FILE: {path}\n```typescript\n{content}\n```"
        for path, content in list(files_with_issues.items())[:20]  # limit to 20 files per call
    )

    return f"""Perform a comprehensive security audit and apply fixes to these Angular files.

## Static Analysis Results
{static_report.to_markdown()}

## Analysis Context
{analysis[:1500]}

## Files with Potential Security Issues
{files_section}

---

## Required Security Audit

### 1. Validate and Fix All Static Analysis Findings
For each finding, either:
- Apply the fix directly in the migrated code, OR
- Explain why it's a false positive

### 2. Additional Deep Security Review
Check for:
- **XSS**: Any use of [innerHTML], DomSanitizer.bypassSecurityTrust*, outerHTML, insertAdjacentHTML
- **CSRF**: Ensure HttpClient requests use proper CSRF tokens where needed
- **Injection**: Template injection via dynamic component creation
- **Insecure Deserialization**: JSON.parse without validation
- **Sensitive Data Exposure**: Passwords, tokens, keys in source code
- **Broken Access Control**: Route guards, authentication checks
- **Security Misconfiguration**: CORS settings, CSP headers
- **Outdated Dependencies**: Any known vulnerable packages
- **ReDoS**: Dangerous regex patterns
- **Prototype Pollution**: Object.assign, spread with untrusted input

### 3. Angular-Specific Security
- Ensure DomSanitizer is used correctly (not bypassed unnecessarily)
- Verify HttpClient interceptors for auth tokens
- Check route guards are properly implemented
- Verify environment variables are not hardcoded
- Check that no secrets appear in browser-accessible code

### 4. Content Security Policy Recommendation
Provide a recommended CSP header for this application's index.html.

### 5. Security Improvements
Any proactive security improvements beyond fixing vulnerabilities.

---

Output ONLY the files that needed security changes, in === MIGRATED FILE: === format.
After the files, provide a ## Security Audit Report section with a complete summary.
"""


def run(
    scan: ProjectScan,
    migrated_files: Dict[str, str],
    analysis: str,
    client: AIClient,
    on_chunk=None,
    logger=None,
) -> Tuple[Dict[str, str], str, SecurityReport]:
    """
    Run security hardening phase.
    Returns (secured_files, full_report, static_report).
    """
    if logger:
        logger.info("Running static security scan...")

    # Static scan on migrated TypeScript files
    ts_files = {k: v for k, v in migrated_files.items() if k.endswith((".ts", ".js", ".html"))}
    static_report = static_scan(ts_files)

    if logger:
        logger.info(f"Static scan: {static_report.summary()}")

    # Identify files with issues
    affected_paths = {issue.file_path for issue in static_report.issues}

    # Also include files that commonly have security concerns
    security_sensitive_patterns = [
        "auth", "login", "token", "password", "user", "guard",
        "interceptor", "http", "api", "service",
    ]
    for path, content in migrated_files.items():
        if any(p in path.lower() for p in security_sensitive_patterns):
            affected_paths.add(path)

    # Build set of files to send for AI security review
    files_for_review = {
        path: migrated_files[path]
        for path in affected_paths
        if path in migrated_files
    }

    if logger:
        logger.info(f"Sending {len(files_for_review)} files for AI security review...")

    # Process in chunks if too many files
    all_secured: Dict[str, str] = {}
    full_report_parts = [f"# Security Phase Report\n\n{static_report.to_markdown()}\n"]

    # Chunk files into batches of 15
    file_items = list(files_for_review.items())
    batch_size = 15
    for batch_start in range(0, len(file_items), batch_size):
        batch = dict(file_items[batch_start:batch_start + batch_size])

        user_prompt = build_security_prompt(batch, static_report, analysis)

        result = client.complete(
            system=SYSTEM_PROMPT,
            user=user_prompt,
            max_tokens=8192,
            on_chunk=on_chunk,
            phase_name="Security",
        )

        secured = extract_migrated_files(result)
        all_secured.update(secured)
        full_report_parts.append(result)

    # Merge secured files into migrated files (secured versions take precedence)
    final_files = dict(migrated_files)
    final_files.update(all_secured)

    if logger:
        logger.info(f"Security phase complete. Fixed {len(all_secured)} files.")

    full_report = "\n\n---\n\n".join(full_report_parts)
    return final_files, full_report, static_report
