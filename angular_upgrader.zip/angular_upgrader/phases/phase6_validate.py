"""
Phase 6: Validation and Report Generation
Validates migration completeness and generates the final MIGRATION_REPORT.md
"""

import json
from datetime import datetime
from typing import Dict, Optional

from core.scanner import ProjectScan
from core.ai_client import AIClient
from phases.phase5_security import SecurityReport

SYSTEM_PROMPT = """You are an Angular migration quality assurance engineer.
You validate Angular 17 migrations and produce comprehensive technical reports.
Be precise, thorough, and actionable.
Use markdown formatting."""


def build_validation_prompt(
    scan: ProjectScan,
    migrated_files: Dict[str, str],
    analysis: str,
    plan: str,
    security_report: SecurityReport,
) -> str:
    migrated_list = "\n".join(f"- {p}" for p in sorted(migrated_files.keys()))
    original_list = "\n".join(f"- {f.rel_path}" for f in scan.get_source_files())

    # Sample a few migrated files for spot-check
    sample_files = []
    priority_checks = ["app.config.ts", "app.routes.ts", "main.ts"]
    for path in priority_checks:
        for mp in migrated_files:
            if mp.endswith(path) and migrated_files[mp]:
                sample_files.append(f"### FILE: {mp}\n```typescript\n{migrated_files[mp][:2000]}\n```")
                break

    sample_section = "\n\n".join(sample_files[:5])

    return f"""Validate this Angular 17 migration and produce the final report.

## Original Project
- Version: {scan.detected_version}
- Source files: {scan.source_files}
- Total files: {scan.total_files}

## Migration Output
Files migrated ({len(migrated_files)} total):
{migrated_list}

## Original Files
{original_list}

## Security Summary
{security_report.summary()}

## Sample Migrated Files (for spot-check)
{sample_section}

## Analysis Summary
{analysis[:2000]}

---

Produce the complete MIGRATION_REPORT.md with:

## ✅ Migration Validation Checklist
Go through each item and mark PASS / FAIL / PARTIAL / N/A:

### Angular 17 Requirements
- [ ] All AngularJS modules converted
- [ ] No angular.module() calls remaining  
- [ ] No $scope usage remaining
- [ ] No $http usage (replaced by HttpClient)
- [ ] No $q / deferred promises (replaced by RxJS)
- [ ] All ng-* directives replaced in templates
- [ ] Routing migrated to @angular/router
- [ ] All controllers converted to components
- [ ] All factories/services converted to @Injectable
- [ ] All directives converted
- [ ] All filters converted to pipes
- [ ] Bootstrap file (main.ts) correct
- [ ] app.config.ts properly configured
- [ ] TypeScript strict mode enabled
- [ ] No 'any' types (or documented exceptions)
- [ ] All imports use Angular 17 packages

### Security
- [ ] No eval() usage
- [ ] No unsafe innerHTML assignments
- [ ] No hardcoded credentials
- [ ] DomSanitizer used correctly
- [ ] HTTP interceptors in place
- [ ] Route guards implemented
- [ ] No console.log in production code

### Build Readiness
- [ ] package.json has correct Angular 17 dependencies
- [ ] tsconfig.json configured correctly
- [ ] angular.json updated
- [ ] Environment files present

## ⚠️ Issues Found
List any validation failures with file references and how to fix.

## 📊 Migration Statistics
| Metric | Value |
|--------|-------|
| Original Angular Version | {scan.detected_version} |
| Target Angular Version | 17+ |
| Source Files Processed | {scan.source_files} |
| Files Generated | {len(migrated_files)} |
| Security Issues Fixed | (from security phase) |
| Critical Vulnerabilities | {security_report.critical_count} |
| High Vulnerabilities | {security_report.high_count} |

## 🚀 Build & Run Instructions

### Prerequisites
```bash
node --version   # Must be >= 18.0.0
npm --version    # Must be >= 9.0.0
```

### Install Dependencies
```bash
cd <project-output-dir>
npm install
```

### Development Server
```bash
ng serve
# Open: http://localhost:4200
```

### Production Build
```bash
ng build --configuration production
```

### Run Tests
```bash
ng test
ng e2e  # if e2e tests exist
```

### Lint
```bash
ng lint
```

## 🔧 Manual Steps Required
List items that MUST be done manually (cannot be automated):
1. API endpoint URLs (update environment files)
2. Authentication/OAuth configuration
3. Server-side CORS configuration
4. CI/CD pipeline updates
5. Any third-party library migrations
(Be specific based on what was found in this project)

## 📚 Post-Migration Recommendations
- Upgrade path to Angular 18+ (signals, etc.)
- Performance optimisations to consider
- Testing improvements
- Code quality improvements

## 🆘 Troubleshooting
Common issues and how to fix them for this specific project.
"""


def generate_report(
    scan: ProjectScan,
    migrated_files: Dict[str, str],
    analysis: str,
    plan: str,
    security_log: str,
    security_report: SecurityReport,
    client: AIClient,
    on_chunk=None,
    logger=None,
) -> str:
    """Generate the final validation report."""
    if logger:
        logger.info("Generating final validation report...")

    user_prompt = build_validation_prompt(
        scan, migrated_files, analysis, plan, security_report
    )

    result = client.complete(
        system=SYSTEM_PROMPT,
        user=user_prompt,
        max_tokens=8192,
        on_chunk=on_chunk,
        phase_name="Validation",
    )

    # Prepend metadata header
    header = f"""# Angular Migration Report
**Generated**: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}  
**Tool**: Angular AI Upgrader  
**Source Version**: {scan.detected_version}  
**Target Version**: Angular 17+  
**Project**: {scan.root_path}  

---

"""
    return header + result
