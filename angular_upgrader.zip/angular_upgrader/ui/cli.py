"""
CLI — Command-line interface for Angular AI Upgrader.
Orchestrates all migration phases with progress reporting.
"""

import argparse
import sys
import os
import time
from pathlib import Path
from typing import Optional, Dict

from config.settings import ANTHROPIC_API_KEY, PHASES
from core.scanner import ProjectScanner
from core.ai_client import AIClient
from core.writer import OutputWriter
from ui.logger import Logger


class CLI:
    """Main CLI orchestrator."""

    def __init__(self):
        self.logger: Optional[Logger] = None
        self.client: Optional[AIClient] = None
        self.writer: Optional[OutputWriter] = None

    def run(self):
        args = self._parse_args()
        self.logger = Logger(verbose=args.verbose, log_file=args.log_file)
        self.logger.banner()

        # Validate API key
        api_key = args.api_key or os.environ.get("ANTHROPIC_API_KEY", "")
        if not api_key:
            self.logger.error(
                "ANTHROPIC_API_KEY is not set.\n"
                "  Set it: export ANTHROPIC_API_KEY=sk-ant-...\n"
                "  Or pass: --api-key sk-ant-..."
            )
            sys.exit(1)

        # Validate input path
        if not Path(args.input).exists():
            self.logger.error(f"Input path does not exist: {args.input}")
            sys.exit(1)

        # Determine output path
        output_path = args.output or (str(Path(args.input).parent / (Path(args.input).name + "_angular17")))

        self.logger.info(f"Input  : {args.input}")
        self.logger.info(f"Output : {output_path}")
        self.logger.info(f"Model  : {args.model or 'claude-opus-4-6 (default)'}")
        self.logger.separator()

        # Initialise components
        try:
            self.client = AIClient(api_key=api_key, logger=self.logger)
            if args.model:
                self.client.model = args.model

            self.writer = OutputWriter(output_path, logger=self.logger)
        except Exception as e:
            self.logger.error(f"Initialisation failed: {e}")
            sys.exit(1)

        # Run the migration
        try:
            self._run_migration(args.input, output_path, args)
        except KeyboardInterrupt:
            self.logger.warning("\nMigration interrupted by user.")
            sys.exit(130)
        except Exception as e:
            self.logger.error(f"Migration failed: {e}")
            if args.verbose:
                import traceback
                traceback.print_exc()
            sys.exit(1)
        finally:
            self.logger.close()

    def _run_migration(self, input_path: str, output_path: str, args):
        total_start = time.time()

        # ── Step 0: Scan project ──────────────────────────────────────────
        self.logger.phase_start("scan", "Project Scan", "📁", "Reading project files...")
        scanner = ProjectScanner(logger=self.logger)
        scan = scanner.scan(input_path)
        self.logger.info(scan.summary())
        if scan.errors:
            for err in scan.errors[:5]:
                self.logger.warning(f"Scan warning: {err}")
        self.logger.phase_end("Project Scan", 0)

        # Prepare output directory
        self.writer.prepare_output_dir()

        # Phase results storage
        results: Dict[str, str] = {}
        migrated_files: Dict[str, str] = {}

        # ── Phase 1: Analysis ─────────────────────────────────────────────
        if not args.skip_to or args.skip_to in ("analyze", "analysis"):
            results["analyze"] = self._run_phase(
                "analyze", "Project Analysis", "🔍",
                "Scanning all patterns, dependencies, and architecture...",
                lambda cb: __import__("phases.phase1_analyze", fromlist=["run"]).run(
                    scan, self.client, on_chunk=cb, logger=self.logger
                ),
            )
        else:
            results["analyze"] = "(skipped)"

        # ── Phase 2: Planning ─────────────────────────────────────────────
        if not self._should_skip(args.skip_to, "plan"):
            results["plan"] = self._run_phase(
                "plan", "Migration Planning", "📋",
                "Building file-by-file migration plan...",
                lambda cb: __import__("phases.phase2_plan", fromlist=["run"]).run(
                    scan, results["analyze"], self.client, on_chunk=cb, logger=self.logger
                ),
            )
        else:
            results["plan"] = "(skipped)"

        # ── Phase 3: Dependencies ─────────────────────────────────────────
        if not self._should_skip(args.skip_to, "dependencies"):
            dep_migrated, results["dependencies"] = self._run_phase_with_files(
                "dependencies", "Dependency Migration", "📦",
                "Updating package.json, tsconfig, angular.json...",
                lambda cb: __import__("phases.phase3_dependencies", fromlist=["run"]).run(
                    scan, results["analyze"], results["plan"],
                    self.client, on_chunk=cb, logger=self.logger
                ),
            )
            migrated_files.update(dep_migrated)
        else:
            results["dependencies"] = "(skipped)"

        # ── Phase 4: Code Migration ───────────────────────────────────────
        if not self._should_skip(args.skip_to, "migrate"):
            code_migrated, results["migrate"] = self._run_phase_with_files(
                "migrate", "Code Migration", "⚙️",
                f"Converting {scan.source_files} source files to Angular 17+...",
                lambda cb: __import__("phases.phase4_migrate", fromlist=["run"]).run(
                    scan, results["analyze"], results["plan"], migrated_files,
                    self.client, on_chunk=cb, logger=self.logger
                ),
            )
            migrated_files.update(code_migrated)
        else:
            results["migrate"] = "(skipped)"

        # ── Phase 5: Security ─────────────────────────────────────────────
        if not args.skip_security and not self._should_skip(args.skip_to, "security"):
            from phases.phase5_security import run as security_run
            phase_start = time.time()
            self.logger.phase_start("security", "Security Hardening", "🛡️",
                                    "Static analysis + AI security fixes...")

            def _security_cb(text):
                self.logger.stream_update(text)

            secured_files, security_log, static_report = security_run(
                scan, migrated_files, results["analyze"],
                self.client, on_chunk=_security_cb, logger=self.logger
            )
            self.logger.stream_end()
            migrated_files.update(secured_files)
            results["security"] = security_log

            self.writer.write_phase_log("phase5_security", security_log)
            self.logger.phase_end("Security Hardening", time.time() - phase_start)
        else:
            static_report = None
            results["security"] = "(skipped)"

        # ── Phase 6: Validation & Report ──────────────────────────────────
        from phases.phase5_security import SecurityReport
        if static_report is None:
            static_report = SecurityReport()

        results["validate"] = self._run_phase(
            "validate", "Validation & Report", "✅",
            "Verifying migration completeness...",
            lambda cb: __import__("phases.phase6_validate", fromlist=["generate_report"]).generate_report(
                scan, migrated_files, results["analyze"], results["plan"],
                results.get("security", ""), static_report,
                self.client, on_chunk=cb, logger=self.logger
            ),
        )

        # ── Write output ──────────────────────────────────────────────────
        self.logger.info("Writing migrated files to output directory...")
        write_result = self.writer.write_migrated_files(migrated_files, scan)

        # Write phase logs
        for phase_id, content in results.items():
            if content and content != "(skipped)":
                self.writer.write_phase_log(f"phase_{phase_id}", content)

        # Write migration report
        report_path = self.writer.write_report(results["validate"])

        # Write diff summary
        diff = self.writer.generate_diff_summary(scan, migrated_files)
        self.writer.write_report(diff, "DIFF_SUMMARY.md")

        # ── Final summary ─────────────────────────────────────────────────
        elapsed = time.time() - total_start
        self.logger.separator()
        self.logger.success(f"Migration complete in {elapsed:.0f}s!")
        self.logger.summary_table([
            ("Output directory",    output_path),
            ("Files migrated",      str(write_result.files_written)),
            ("Assets copied",       str(write_result.files_copied)),
            ("Migration report",    report_path),
            ("API usage",           self.client.stats()),
        ], title="Summary")

        if write_result.errors:
            self.logger.warning(f"Write errors: {len(write_result.errors)}")
            for err in write_result.errors[:5]:
                self.logger.warning(f"  {err}")

        self.logger.info(f"\nNext steps:")
        self.logger.info(f"  cd {output_path}")
        self.logger.info(f"  npm install")
        self.logger.info(f"  ng serve")
        self.logger.info(f"\nSee MIGRATION_REPORT.md for full details.")

    # ─── Phase runners ────────────────────────────────────────────────────

    def _run_phase(self, phase_id, phase_name, icon, desc, fn) -> str:
        start = time.time()
        self.logger.phase_start(phase_id, phase_name, icon, desc)

        chunk_accumulator = [""]
        def cb(text):
            chunk_accumulator[0] = text
            self.logger.stream_update(text)

        try:
            result = fn(cb)
            self.logger.stream_end()
            self.writer.write_phase_log(f"phase_{phase_id}", result)
            self.logger.phase_end(phase_name, time.time() - start)
            return result
        except Exception as e:
            self.logger.stream_end()
            self.logger.phase_error(phase_name, str(e))
            raise

    def _run_phase_with_files(self, phase_id, phase_name, icon, desc, fn):
        """Like _run_phase but the function returns (files_dict, log_text)."""
        start = time.time()
        self.logger.phase_start(phase_id, phase_name, icon, desc)

        chunk_accumulator = [""]
        def cb(text):
            chunk_accumulator[0] = text
            self.logger.stream_update(text)

        try:
            files_dict, log_text = fn(cb)
            self.logger.stream_end()
            self.writer.write_phase_log(f"phase_{phase_id}", log_text)
            self.logger.phase_end(phase_name, time.time() - start)
            return files_dict, log_text
        except Exception as e:
            self.logger.stream_end()
            self.logger.phase_error(phase_name, str(e))
            raise

    # ─── Helpers ──────────────────────────────────────────────────────────

    @staticmethod
    def _should_skip(skip_to: Optional[str], current: str) -> bool:
        if not skip_to:
            return False
        order = ["analyze", "plan", "dependencies", "migrate", "security", "validate"]
        if skip_to in order and current in order:
            return order.index(current) < order.index(skip_to)
        return False

    def _parse_args(self) -> argparse.Namespace:
        parser = argparse.ArgumentParser(
            prog="angular-upgrader",
            description="AI-powered Angular 1.x → Angular 17+ migration tool",
            formatter_class=argparse.RawDescriptionHelpFormatter,
            epilog="""
Examples:
  # Basic upgrade
  python main.py --input ./my-angular-app --output ./my-angular-app-v17

  # Dry run (analysis + plan only)
  python main.py --input ./my-app --dry-run

  # Skip security phase (faster)
  python main.py --input ./my-app --skip-security

  # Resume from migrate phase (if analysis/plan already done)
  python main.py --input ./my-app --skip-to migrate

  # Use a specific API key
  python main.py --input ./my-app --api-key sk-ant-...

  # Verbose with log file
  python main.py --input ./my-app --verbose --log-file upgrade.log
            """,
        )

        parser.add_argument(
            "--input", "-i",
            required=True,
            help="Path to the Angular 1.x project directory",
        )
        parser.add_argument(
            "--output", "-o",
            help="Output directory for migrated project (default: <input>_angular17)",
        )
        parser.add_argument(
            "--api-key",
            help="Anthropic API key (default: ANTHROPIC_API_KEY env var)",
        )
        parser.add_argument(
            "--model",
            help="Claude model to use (default: claude-opus-4-6)",
        )
        parser.add_argument(
            "--dry-run",
            action="store_true",
            help="Run analysis and planning only, do not write output files",
        )
        parser.add_argument(
            "--skip-security",
            action="store_true",
            help="Skip the security hardening phase",
        )
        parser.add_argument(
            "--skip-to",
            choices=["analyze", "plan", "dependencies", "migrate", "security", "validate"],
            help="Skip phases before this one (for resuming interrupted runs)",
        )
        parser.add_argument(
            "--verbose", "-v",
            action="store_true",
            help="Enable verbose/debug output",
        )
        parser.add_argument(
            "--log-file",
            help="Write log output to this file",
        )

        return parser.parse_args()
