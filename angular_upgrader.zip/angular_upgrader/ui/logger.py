"""
Logger — rich terminal output with color, phase tracking, and live streaming.
Falls back gracefully if 'rich' is not installed.
"""

import sys
import time
import os
from typing import Optional

# Try to use rich for beautiful output
try:
    from rich.console import Console
    from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
    from rich.panel import Panel
    from rich.text import Text
    from rich.live import Live
    from rich.table import Table
    from rich import print as rprint
    HAS_RICH = True
except ImportError:
    HAS_RICH = False


LEVEL_COLORS = {
    "DEBUG":   "\033[90m",   # Dark gray
    "INFO":    "\033[36m",   # Cyan
    "SUCCESS": "\033[32m",   # Green
    "WARNING": "\033[33m",   # Yellow
    "ERROR":   "\033[31m",   # Red
    "PHASE":   "\033[35m",   # Magenta
    "STREAM":  "\033[37m",   # White
}
RESET = "\033[0m"
BOLD  = "\033[1m"


class Logger:
    """
    Terminal logger with optional rich formatting.
    Supports live streaming of AI output.
    """

    def __init__(self, verbose: bool = False, log_file: Optional[str] = None):
        self.verbose = verbose
        self.log_file = log_file
        self._log_fh = None
        self._stream_active = False
        self._last_stream_lines = 0

        if HAS_RICH:
            self.console = Console()
        else:
            self.console = None

        if log_file:
            self._log_fh = open(log_file, "a", encoding="utf-8")

    # ─── Core log methods ─────────────────────────────────────────────────

    def debug(self, msg: str):
        if self.verbose:
            self._print("DEBUG", msg)

    def info(self, msg: str):
        self._print("INFO", msg)

    def success(self, msg: str):
        self._print("SUCCESS", msg)

    def warning(self, msg: str):
        self._print("WARNING", msg)

    def error(self, msg: str):
        self._print("ERROR", msg, file=sys.stderr)

    def phase_start(self, phase_id: str, phase_name: str, icon: str, desc: str):
        self._clear_stream()
        border = "═" * 60
        msg = f"\n{border}\n  {icon}  {phase_name.upper()}\n  {desc}\n{border}"
        self._print("PHASE", msg)

    def phase_end(self, phase_name: str, elapsed: float):
        self._print("SUCCESS", f"✓ {phase_name} completed in {elapsed:.1f}s")

    def phase_error(self, phase_name: str, error: str):
        self._print("ERROR", f"✗ {phase_name} failed: {error}")

    # ─── Live streaming ────────────────────────────────────────────────────

    def stream_update(self, text: str):
        """Update live streaming output from AI."""
        # Show last 15 lines of streaming text
        lines = text.splitlines()
        display_lines = lines[-15:]
        output = "\n".join(display_lines)

        if self._last_stream_lines > 0:
            # Move cursor up to overwrite previous stream output
            sys.stdout.write(f"\033[{self._last_stream_lines}A\033[J")

        sys.stdout.write(f"{LEVEL_COLORS['STREAM']}{output}{RESET}\n")
        sys.stdout.flush()
        self._last_stream_lines = len(display_lines) + 1
        self._stream_active = True

    def stream_end(self):
        """Clear streaming state."""
        self._clear_stream()

    def _clear_stream(self):
        if self._stream_active and self._last_stream_lines > 0:
            sys.stdout.write(f"\033[{self._last_stream_lines}A\033[J")
            sys.stdout.flush()
        self._stream_active = False
        self._last_stream_lines = 0

    # ─── Banners ──────────────────────────────────────────────────────────

    def banner(self):
        lines = [
            "",
            f"{BOLD}{LEVEL_COLORS['PHASE']}╔══════════════════════════════════════════════════════╗",
            f"║          ⚡  Angular AI Upgrader                    ║",
            f"║          Angular 1.x  →  Angular 17+               ║",
            f"╚══════════════════════════════════════════════════════╝{RESET}",
            "",
        ]
        print("\n".join(lines))

    def summary_table(self, rows: list, title: str = ""):
        """Print a simple ASCII table."""
        if not rows:
            return
        print(f"\n{BOLD}{title}{RESET}" if title else "")
        for label, value in rows:
            print(f"  {LEVEL_COLORS['INFO']}{label:<30}{RESET} {value}")

    def separator(self):
        print(f"\n{LEVEL_COLORS['DEBUG']}{'─' * 60}{RESET}")

    # ─── Internal ─────────────────────────────────────────────────────────

    def _print(self, level: str, msg: str, file=sys.stdout):
        color = LEVEL_COLORS.get(level, "")
        prefix = {
            "DEBUG":   "  ·",
            "INFO":    "  →",
            "SUCCESS": "  ✓",
            "WARNING": "  ⚠",
            "ERROR":   "  ✗",
            "PHASE":   "",
            "STREAM":  "",
        }.get(level, "  ")

        formatted = f"{color}{prefix} {msg}{RESET}"
        print(formatted, file=file)

        if self._log_fh:
            import datetime
            ts = datetime.datetime.now().strftime("%H:%M:%S")
            self._log_fh.write(f"[{ts}] [{level}] {msg}\n")
            self._log_fh.flush()

    def close(self):
        if self._log_fh:
            self._log_fh.close()
